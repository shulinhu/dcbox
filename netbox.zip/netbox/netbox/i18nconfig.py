import os
from django.utils.translation import ugettext_lazy as _

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

USE_I18N = True
USE_L10N = True
USE_TZ = True

TIME_ZONE = 'Asia/Shanghai'

LANGUAGES = (
    ('en', _('English')),
    ('zh-hans', _('Simple Chinese')),
)
LANGUAGE_CODE = 'zh-hans'

LOCALE_PATHS = (
    os.path.join(BASE_DIR, 'locale'),
)

