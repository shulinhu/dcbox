from django import forms
from django.utils.translation import ugettext_lazy as _
from taggit.forms import TagField

from dcim.models import Region, Site
from extras.forms import (
    AddRemoveTagsForm, CustomFieldBulkEditForm, CustomFieldFilterForm, CustomFieldModelForm, CustomFieldModelCSVForm,
)
from tenancy.forms import TenancyFilterForm, TenancyForm
from tenancy.models import Tenant
from utilities.forms import (
    APISelect, APISelectMultiple, add_blank_choice, BootstrapMixin, CommentField, CSVChoiceField, DatePicker,
    FilterChoiceField, SmallTextarea, SlugField, StaticSelect2, StaticSelect2Multiple, TagFilterField
)
from .choices import CircuitStatusChoices
from .models import Circuit, CircuitTermination, CircuitType, Provider


#
# Providers
#

class ProviderForm(BootstrapMixin, CustomFieldModelForm):
    slug = SlugField()
    comments = CommentField()
    tags = TagField(
        required=False
    )

    class Meta:
        model = Provider
        fields = [
            'name', 'slug', 'asn', 'account', 'portal_url', 'noc_contact', 'admin_contact', 'comments', 'tags',
        ]
        widgets = {
            'noc_contact': SmallTextarea(
                attrs={'rows': 5}
            ),
            'admin_contact': SmallTextarea(
                attrs={'rows': 5}
            ),
        }
        help_texts = {
            'name': _("Full name of the provider"),
            'asn': _("BGP autonomous system number (if applicable)"),
            'portal_url': _("URL of the provider's customer support portal"),
            'noc_contact': _("NOC email address and phone number"),
            'admin_contact': _("Administrative contact email address and phone number"),
        }


class ProviderCSVForm(CustomFieldModelCSVForm):
    slug = SlugField()

    class Meta:
        model = Provider
        fields = Provider.csv_headers
        help_texts = {
            'name': _('Provider name'),
            'asn': _('32-bit autonomous system number'),
            'portal_url': _('Portal URL'),
            'comments': _('Free-form comments'),
        }


class ProviderBulkEditForm(BootstrapMixin, AddRemoveTagsForm, CustomFieldBulkEditForm):
    pk = forms.ModelMultipleChoiceField(
        queryset=Provider.objects.all(),
        widget=forms.MultipleHiddenInput
    )
    asn = forms.IntegerField(
        required=False,
        label=_('ASN')
    )
    account = forms.CharField(
        max_length=30,
        required=False,
        label=_('Account number')
    )
    portal_url = forms.URLField(
        required=False,
        label=_('Portal')
    )
    noc_contact = forms.CharField(
        required=False,
        widget=SmallTextarea,
        label=_('NOC contact')
    )
    admin_contact = forms.CharField(
        required=False,
        widget=SmallTextarea,
        label=_('Admin contact')
    )
    comments = CommentField(
        widget=SmallTextarea,
        label=_('Comments')
    )

    class Meta:
        nullable_fields = [
            'asn', 'account', 'portal_url', 'noc_contact', 'admin_contact', 'comments',
        ]


class ProviderFilterForm(BootstrapMixin, CustomFieldFilterForm):
    model = Provider
    q = forms.CharField(
        required=False,
        label='Search'
    )
    region = FilterChoiceField(
        queryset=Region.objects.all(),
        to_field_name='slug',
        required=False,
        widget=APISelectMultiple(
            api_url="/api/dcim/regions/",
            value_field="slug",
            filter_for={
                'site': 'region'
            }
        ),
        label=_('Region')
    )
    site = FilterChoiceField(
        queryset=Site.objects.all(),
        to_field_name='slug',
        widget=APISelectMultiple(
            api_url="/api/dcim/sites/",
            value_field="slug",
        ),
        label=_('Site')
    )
    asn = forms.IntegerField(
        required=False,
        label=_('ASN'),
    )
    tag = TagFilterField(model)


#
# Circuit types
#

class CircuitTypeForm(BootstrapMixin, forms.ModelForm):
    slug = SlugField()

    class Meta:
        model = CircuitType
        fields = [
            'name', 'slug', 'description',
        ]


class CircuitTypeCSVForm(forms.ModelForm):
    slug = SlugField()

    class Meta:
        model = CircuitType
        fields = CircuitType.csv_headers
        help_texts = {
            'name': _('Name of circuit type'),
        }


#
# Circuits
#

class CircuitForm(BootstrapMixin, TenancyForm, CustomFieldModelForm):
    comments = CommentField()
    tags = TagField(
        required=False
    )

    class Meta:
        model = Circuit
        fields = [
            'cid', 'type', 'provider', 'status', 'install_date', 'commit_rate', 'description', 'tenant_group', 'tenant',
            'comments', 'tags',
        ]
        help_texts = {
            'cid': _("Unique circuit ID"),
            'commit_rate': _("Committed rate"),
        }
        widgets = {
            'provider': APISelect(
                api_url="/api/circuits/providers/"
            ),
            'type': APISelect(
                api_url="/api/circuits/circuit-types/"
            ),
            'status': StaticSelect2(),
            'install_date': DatePicker(),
        }


class CircuitCSVForm(CustomFieldModelCSVForm):
    provider = forms.ModelChoiceField(
        queryset=Provider.objects.all(),
        to_field_name='name',
        help_text=_('Name of parent provider'),
        error_messages={
            'invalid_choice': _('Provider not found.')
        }
    )
    type = forms.ModelChoiceField(
        queryset=CircuitType.objects.all(),
        to_field_name='name',
        help_text=_('Type of circuit'),
        error_messages={
            'invalid_choice': _('Invalid circuit type.')
        }
    )
    status = CSVChoiceField(
        choices=CircuitStatusChoices,
        required=False,
        help_text=_('Operational status')
    )
    tenant = forms.ModelChoiceField(
        queryset=Tenant.objects.all(),
        required=False,
        to_field_name='name',
        help_text=_('Name of assigned tenant'),
        error_messages={
            'invalid_choice': _('Tenant not found.')
        }
    )

    class Meta:
        model = Circuit
        fields = [
            'cid', 'provider', 'type', 'status', 'tenant', 'install_date', 'commit_rate', 'description', 'comments',
        ]


class CircuitBulkEditForm(BootstrapMixin, AddRemoveTagsForm, CustomFieldBulkEditForm):
    pk = forms.ModelMultipleChoiceField(
        queryset=Circuit.objects.all(),
        widget=forms.MultipleHiddenInput
    )
    type = forms.ModelChoiceField(
        queryset=CircuitType.objects.all(),
        required=False,
        widget=APISelect(
            api_url="/api/circuits/circuit-types/"
        )
    )
    provider = forms.ModelChoiceField(
        queryset=Provider.objects.all(),
        required=False,
        widget=APISelect(
            api_url="/api/circuits/providers/"
        )
    )
    status = forms.ChoiceField(
        choices=add_blank_choice(CircuitStatusChoices),
        required=False,
        initial='',
        widget=StaticSelect2()
    )
    tenant = forms.ModelChoiceField(
        queryset=Tenant.objects.all(),
        required=False,
        widget=APISelect(
            api_url="/api/tenancy/tenants/"
        )
    )
    commit_rate = forms.IntegerField(
        required=False,
        label=_('Commit rate (Kbps)')
    )
    description = forms.CharField(
        max_length=100,
        required=False
    )
    comments = CommentField(
        widget=SmallTextarea,
        label=_('Comments')
    )

    class Meta:
        nullable_fields = [
            'tenant', 'commit_rate', 'description', 'comments',
        ]


class CircuitFilterForm(BootstrapMixin, TenancyFilterForm, CustomFieldFilterForm):
    model = Circuit
    field_order = [
        'q', 'type', 'provider', 'status', 'region', 'site', 'tenant_group', 'tenant', 'commit_rate',
    ]
    q = forms.CharField(
        required=False,
        label='Search'
    )
    type = FilterChoiceField(
        queryset=CircuitType.objects.all(),
        to_field_name='slug',
        widget=APISelectMultiple(
            api_url="/api/circuits/circuit-types/",
            value_field="slug",
        ),
        label=_('Type')
    )
    provider = FilterChoiceField(
        queryset=Provider.objects.all(),
        to_field_name='slug',
        widget=APISelectMultiple(
            api_url="/api/circuits/providers/",
            value_field="slug",
        ),
        label=_('Circuit Provides')
    )
    status = forms.MultipleChoiceField(
        choices=CircuitStatusChoices,
        required=False,
        widget=StaticSelect2Multiple(),
        label=_('Status')
    )
    region = forms.ModelMultipleChoiceField(
        queryset=Region.objects.all(),
        to_field_name='slug',
        required=False,
        widget=APISelectMultiple(
            api_url="/api/dcim/regions/",
            value_field="slug",
            filter_for={
                'site': 'region'
            }
        ),
        label=_('Region')
    )
    site = FilterChoiceField(
        queryset=Site.objects.all(),
        to_field_name='slug',
        widget=APISelectMultiple(
            api_url="/api/dcim/sites/",
            value_field="slug",
        ),
        label=_('Site')
    )
    commit_rate = forms.IntegerField(
        required=False,
        min_value=0,
        label=_('Commit rate (Kbps)')
    )
    tag = TagFilterField(model)


#
# Circuit terminations
#

class CircuitTerminationForm(BootstrapMixin, forms.ModelForm):

    class Meta:
        model = CircuitTermination
        fields = [
            'term_side', 'site', 'port_speed', 'upstream_speed', 'xconnect_id', 'pp_info', 'description',
        ]
        help_texts = {
            'port_speed': _("Physical circuit speed"),
            'xconnect_id': _("ID of the local cross-connect"),
            'pp_info': _("Patch panel ID and port number(s)")
        }
        widgets = {
            'term_side': forms.HiddenInput(),
            'site': APISelect(
                api_url="/api/dcim/sites/"
            )
        }
