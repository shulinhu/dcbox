class LoopDetected(Exception):
    """
    A loop has been detected while tracing a cable path.
    """
    pass
